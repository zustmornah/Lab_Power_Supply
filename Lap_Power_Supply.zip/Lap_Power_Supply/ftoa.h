/*
 * ftoa.h
 *
 *  Created on: Jun 12, 2017
 *      Author: Adom_Kwabena
 */

#ifndef FTOA_H_
#define FTOA_H_


#define PRECISION 3

void float_to_string(float f, char* string);


#endif /* FTOA_H_ */
